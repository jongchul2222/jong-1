<!DOCTYPE html>
<html>
    <head>
        <title>Wikon</title>
        <meta charset="UTF-8">
        <link href="../css/skin.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <header>
            <a class="logo" href="home.html"><img src="../imgs/Logo.png" alt="logo" /> </a>
        </header>
        <section class="content">
            <p>LOGAR </p>
            <form method="POST" action="logar2.php">
                
		<fieldset>
			<legend>Logar</legend><br/>
			<label for="nome">Nome:</label>
			<input type="text" name="nome" id="nome" size="20" /><br /><br/>
			<label for="nome">Senha:</label>
			<input type="password" name="senha" id="senha" size="20" /><br /><br/>
			<p><input type="submit" value="Continuar" name="continuar"></p>
		</fieldset> 
            </form> 
        </section>
        
        <footer>
            <nav class="foot-link">
                <ul class="sobre-links">
                    <li><a href="sobre.html">Sobre Nós</a></li>
                    <li class="sep">   |   </li>
                    <li><a href="termos.html">Termos de uso</a></li>
                    <li class="sep">   |   </li>
                    <li><a href="contato.html">Fale Conosco</a></li>
                </ul>
            </nav>
            <section class="reg-mark">
                <p>Jong Chul Lee- 41455800 - Wikon © 2016</p>
            </section>
        </footer>
    </body>
</html>
