<!DOCTYPE html>
<html>
    <head>
        <title>Wikon</title>
        <meta charset="UTF-8">
        <link href="../css/skin.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <header>
            <a class="logo" href="home.html"><img src="../imgs/Logo.png" alt="logo" /> </a>
        </header>
        <section class="content">
                 <form method="POST" action="publicar2.php">
                
		<fieldset>
			<legend>Publicar</legend><br/>
			<label for="nome">Texto</label>
			<input type="text" name="nome" id="nome" size="200" /><br /><br/>
			<label for="arquivos">Arquivo: </label>
			<input type="hidden" name="MAX_SIZE_FILE" value="100000"> <br/><br/>  
			<input type="file" name="ARQUIVO" id="arquivo"> <br/>  
			<p><input type="submit" value="Finalizar" name="prosseguir"></p> 
		</fieldset> 
            </form> 
        </section>
        
        <footer>
            <nav class="foot-link">
                <ul class="sobre-links">
                    <li><a href="sobre.html">Sobre Nós</a></li>
                    <li class="sep">   |   </li>
                    <li><a href="termos.html">Termos de uso</a></li>
                    <li class="sep">   |   </li>
                    <li><a href="contato.html">Fale Conosco</a></li>
                </ul>
            </nav>
            <section class="reg-mark">
                <p>Jong Chul Lee - 41487788 - Wikon © 2015</p>
            </section>
        </footer>
    </body>
</html>
