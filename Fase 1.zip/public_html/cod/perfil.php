<!DOCTYPE html>
<html>
    <head>
        <title>Wikon</title>
        <meta charset="UTF-8">
        <link href="../css/skin.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <header>
            <a class="logo" href="home.html"><img src="../imgs/Logo.png" alt="logo" /> </a>
        </header>
        <section class="content">
            <form method="POST" action="perfil2.php">
                
		<fieldset>
			<legend>Editar Perfil</legend><br/>
			<label for="nome">Nome:</label>
			<input type="text" name="nome" id="nome" size="20" /><br /><br/>
			<label for="nome">Senha:</label>
			<input type="password" name="senha" id="senha" size="20" /><br /><br/>
			<label for="email">E-mail:</label>
			<input type="email" name="email" id="email" size="20" /><br/><br/>
			<label for="datanascimento">Data de nascimento: </label>
			<input type="date" name="datanascimento" id="datanascimento" size="20" /><br /><br/>
			Sexo: 
			<input type="radio" value="masculino" checked name="sexo" id="masculino">
			<label for="masculino">Masculino</label>
			<input type="radio" name="sexo" value="feminino" id="feminino">
			<label for="feminino">Feminino</label><br /><br/>
			<label for="profissao">Profissao: </label>
			<input type="text" name="profissao" id="profissao" size="20">
			<p><input type="submit" value="Continuar" name="continuar"></p>
		</fieldset> 
            </form> 
        </section>
        
        <footer>
            <nav class="foot-link">
                <ul class="sobre-links">
                    <li><a href="sobre.html">Sobre Nós</a></li>
                    <li class="sep">   |   </li>
                    <li><a href="termos.html">Termos de uso</a></li>
                    <li class="sep">   |   </li>
                    <li><a href="contato.html">Fale Conosco</a></li>
                </ul>
            </nav>
            <section class="reg-mark">
                <p>Jong Chul Lee- 41455800 - Wikon © 2016</p>
            </section>
        </footer>
    </body>
</html>
